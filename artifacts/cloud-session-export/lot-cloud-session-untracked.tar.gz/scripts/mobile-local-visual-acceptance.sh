#!/usr/bin/env bash
# LOT Mobile — local visual acceptance (Home + Catalog + Product Detail)
# Run on Mac with existing LOT_API35_ARM64 AVD. Not for Cloud Agent / Firebase.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

export ANDROID_HOME="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
ADB="$ANDROID_HOME/platform-tools/adb"
EMULATOR="$ANDROID_HOME/emulator/emulator"
AVD_NAME="${AVD_NAME:-LOT_API35_ARM64}"
PACKAGE="ru.lot.marketplace.alpha"

HOME_ART="$ROOT/artifacts/mobile-home-redesign"
CATALOG_ART="$ROOT/artifacts/mobile-catalog-redesign"
PRODUCT_ART="$ROOT/artifacts/mobile-product-detail-redesign"
mkdir -p "$HOME_ART" "$CATALOG_ART" "$PRODUCT_ART"

log() { printf '[local-acceptance] %s\n' "$*"; }
fail() { log "FAIL: $*"; exit 1; }

[[ -x "$ADB" ]] || fail "adb not found at $ADB — set ANDROID_HOME"
[[ -x "$EMULATOR" ]] || fail "emulator not found at $EMULATOR"

wait_boot() {
  "$ADB" wait-for-device
  for _ in $(seq 1 90); do
    boot=$("$ADB" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')
    [[ "$boot" == "1" ]] && return 0
    sleep 2
  done
  fail "emulator boot timeout (sys.boot_completed != 1)"
}

ensure_emulator() {
  if "$ADB" devices | awk 'NR>1 && $2=="device"{exit 0}'; then
    log "device already online"
    return 0
  fi
  log "starting AVD $AVD_NAME"
  "$EMULATOR" -avd "$AVD_NAME" -no-snapshot-load >/tmp/lot-emulator.log 2>&1 &
  wait_boot
}

screencap() {
  local out="$1"
  "$ADB" exec-out screencap -p >"$out"
  log "screenshot → $out"
}

overlay() {
  local ref="$1" actual="$2" out="$3"
  if command -v magick >/dev/null 2>&1; then
    magick "$ref" \( "$actual" -alpha set -channel A -evaluate multiply 0.5 +channel \) -compose over -composite "$out"
    log "overlay → $out"
    return 0
  fi
  if command -v convert >/dev/null 2>&1; then
    convert "$ref" \( "$actual" -alpha set -channel A -evaluate multiply 0.5 +channel \) -compose over -composite "$out"
    log "overlay → $out"
    return 0
  fi
  python3 - "$ref" "$actual" "$out" <<'PY' || true
import sys
from pathlib import Path
try:
    from PIL import Image
except ImportError:
    sys.exit(1)
ref, act, out = sys.argv[1:4]
r = Image.open(ref).convert("RGBA").resize(Image.open(act).size, Image.LANCZOS)
a = Image.open(act).convert("RGBA")
a.putalpha(128)
Image.alpha_composite(r, a).save(out)
print(f"overlay → {out}")
PY
}

install_current() {
  log "building + installing current source (debug)"
  export EXPO_PUBLIC_RELEASE_CHANNEL="${EXPO_PUBLIC_RELEASE_CHANNEL:-staging}"
  export EXPO_PUBLIC_API_BASE_URL="${EXPO_PUBLIC_API_BASE_URL:-https://web-production-e56fb.up.railway.app}"
  (
    cd "$ROOT/apps/mobile"
    npm install --legacy-peer-deps --silent
    npx expo prebuild --platform android --non-interactive
    echo "sdk.dir=$ANDROID_HOME" > android/local.properties
    cd android
    ./gradlew installDebug -q
  )
  "$ADB" shell monkey -p "$PACKAGE" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true
  sleep 5
}

tap() {
  local x="$1" y="$2"
  "$ADB" shell input tap "$x" "$y"
  sleep 1
}

# --- Phase 1: emulator ---
ensure_emulator
wait_boot
WM=$("$ADB" shell wm size | tr -d '\r')
log "display: $WM"

# --- Phase 2: install ---
if [[ "${SKIP_INSTALL:-0}" != "1" ]]; then
  install_current
fi

"$ADB" shell pm list packages | grep -q "$PACKAGE" || fail "package $PACKAGE not installed"

# --- Phase 3: Home ---
"$ADB" shell am start -n "$PACKAGE/.MainActivity" >/dev/null 2>&1 || \
  "$ADB" shell monkey -p "$PACKAGE" -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 6
screencap "$HOME_ART/home-1080x2400.png"
[[ -f "$HOME_ART/reference.png" ]] && overlay "$HOME_ART/reference.png" "$HOME_ART/home-1080x2400.png" "$HOME_ART/overlay.png"

# --- Phase 5: Catalog (tab ~270,2350 on 1080x2400 baseline) ---
tap 540 2350
sleep 5
screencap "$CATALOG_ART/catalog-1080x2400.png"
[[ -f "$CATALOG_ART/reference.png" ]] && overlay "$CATALOG_ART/reference.png" "$CATALOG_ART/catalog-1080x2400.png" "$CATALOG_ART/overlay.png"

# --- Phase 6: Product (tap first grid card ~270,900) ---
tap 270 900
sleep 5
screencap "$PRODUCT_ART/product-1080x2400.png"
[[ -f "$PRODUCT_ART/reference.png" ]] && overlay "$PRODUCT_ART/reference.png" "$PRODUCT_ART/product-1080x2400.png" "$PRODUCT_ART/overlay.png"

# --- UI hierarchy dumps ---
"$ADB" shell uiautomator dump /sdcard/window.xml >/dev/null 2>&1 || true
"$ADB" pull /sdcard/window.xml "$HOME_ART/home.xml" >/dev/null 2>&1 || true
"$ADB" shell uiautomator dump /sdcard/window.xml >/dev/null 2>&1 || true
"$ADB" pull /sdcard/window.xml "$CATALOG_ART/catalog.xml" >/dev/null 2>&1 || true

# --- Logcat snapshot ---
"$ADB" logcat -d -t 200 >"$ROOT/artifacts/mobile-home-redesign/logcat-tail.txt" 2>&1 || true

log "DONE — review screenshots and overlays in artifacts/mobile-*-redesign/"
log "Set SKIP_INSTALL=1 to reuse installed APK on reruns."
